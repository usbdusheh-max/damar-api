const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason
} = require("@whiskeysockets/baileys");

const P = require("pino");
const qrcode = require("qrcode-terminal");

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./auth");

  const sock = makeWASocket({
    auth: state,
    logger: P({ level: "silent" }),
    printQRInTerminal: false
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log("\nScan this QR code with WhatsApp:\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "open") {
      console.log("✅ WhatsApp bot connected!");
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code !== DisconnectReason.loggedOut) {
        console.log("Connection closed. Reconnecting...");
        startBot();
      } else {
        console.log("❌ Logged out. Delete the auth folder and run again.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      "";

    const command = text.trim().toLowerCase();

    if (command === ".ping") {
      await sock.sendMessage(jid, { text: "🏓 Pong!" });
    }

    if (command === ".menu") {
      await sock.sendMessage(jid, {
        text:
`🤖 *BOT MENU*

.ping
.menu
.hello
.help`
      });
    }

    if (command === ".hello") {
      await sock.sendMessage(jid, { text: "👋 مرحبا! أنا بوت واتساب." });
    }

    if (command === ".help") {
      await sock.sendMessage(jid, {
        text: "اكتب .menu لعرض أوامر البوت."
      });
    }
  });
}

startBot().catch(console.error);
