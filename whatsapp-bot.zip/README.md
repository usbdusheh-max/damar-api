# WhatsApp Bot

بوت واتساب بسيط باستخدام Node.js و Baileys.

## التشغيل

```bash
npm install
npm start
```

سيظهر QR في الطرفية. افتح واتساب > الأجهزة المرتبطة > ربط جهاز، ثم امسح QR.

بعد نجاح الربط، ستُحفظ جلسة الدخول داخل مجلد `auth`.

## الأوامر

- `.menu`
- `.ping`
- `.hello`
- `.help`

لا ترفع مجلد `auth` إلى GitHub.
